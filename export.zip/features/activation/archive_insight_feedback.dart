import 'package:flutter/foundation.dart';

import '../../services/app_services.dart';
import '../archive_proof/visible_archive_proof_copy.dart';
import 'archive_home_summary.dart';

/// Which archive insight surface the user is responding to.
enum ArchiveInsightTarget {
  archiveHome,
  weeklyReview,
  beliefEvidence,
  beliefUpdate,
}

/// Local feedback choice — never synced to a backend.
enum ArchiveInsightFeedbackChoice {
  feelsRight,
  notQuite,
}

/// User-facing copy for insight feedback controls.
abstract final class ArchiveInsightFeedbackCopy {
  static const feelsRight = VisibleArchiveProofCopy.insightFeedbackFeelsRight;

  static const notQuite = VisibleArchiveProofCopy.insightFeedbackNotQuite;

  static const hideThis = VisibleArchiveProofCopy.insightFeedbackHideThis;

  static const whySeeing = VisibleArchiveProofCopy.insightFeedbackWhySeeing;

  static const whySource = VisibleArchiveProofCopy.insightFeedbackWhySource;

  static const whyNotConclusion =
      VisibleArchiveProofCopy.insightFeedbackWhyNotConclusion;

  static const whyHide = VisibleArchiveProofCopy.insightFeedbackWhyHide;

  static const correctionAffordance =
      VisibleArchiveProofCopy.insightCorrectionAffordance;

  static const correctionPlaceholder =
      VisibleArchiveProofCopy.insightCorrectionPlaceholder;

  static const correctionSaveCta =
      VisibleArchiveProofCopy.insightCorrectionSaveCta;

  static const correctionSkipCta =
      VisibleArchiveProofCopy.insightCorrectionSkipCta;

  static const correctionMarkedNotQuite =
      VisibleArchiveProofCopy.insightCorrectionMarkedNotQuite;

  static const correctionYourNotePrefix =
      VisibleArchiveProofCopy.insightCorrectionYourNotePrefix;
}

/// Visibility gates — no controls on premature early-ladder surfaces.
abstract final class ArchiveInsightFeedbackGate {
  ArchiveInsightFeedbackGate._();

  static bool showForArchiveHome(ArchiveHomeStage stage) =>
      stage == ArchiveHomeStage.three ||
      stage == ArchiveHomeStage.four ||
      stage == ArchiveHomeStage.fivePlus;

  static bool showForWeeklyReview({required bool hasEnoughEvidence}) =>
      hasEnoughEvidence;

  static bool showForBeliefEvidence({required bool hasEnoughEvidence}) =>
      hasEnoughEvidence;

  static bool showForBeliefUpdate() => true;
}

/// Local-only store for insight feedback and hide state.
abstract final class ArchiveInsightFeedbackStore {
  ArchiveInsightFeedbackStore._();

  static const _prefsKey = 'archive_insight_feedback';

  static const maxCorrectionNoteLength = 240;

  static final Set<String> _hidden = <String>{};
  static final Map<String, int> _feelsRight = <String, int>{};
  static final Map<String, int> _notQuite = <String, int>{};
  static final Map<String, String> _correctionNotes = <String, String>{};

  static String archiveHomeId(ArchiveHomeStage stage) =>
      'archive_home_${stage.name}';

  static String targetId(ArchiveInsightTarget target) => target.name;

  static bool isHidden(String insightId) => _hidden.contains(insightId);

  static int feelsRightCount(String insightId) => _feelsRight[insightId] ?? 0;

  static int notQuiteCount(String insightId) => _notQuite[insightId] ?? 0;

  static String? correctionNote(String insightId) => _correctionNotes[insightId];

  static bool hasCorrectionNote(String insightId) =>
      (_correctionNotes[insightId]?.trim().isNotEmpty ?? false);

  /// Returns trimmed note capped at [maxCorrectionNoteLength], or null if empty.
  static String? normalizeCorrectionNote(String rawNote) {
    final trimmed = rawNote.trim();
    if (trimmed.isEmpty) return null;
    if (trimmed.length <= maxCorrectionNoteLength) return trimmed;
    return trimmed.substring(0, maxCorrectionNoteLength);
  }

  static bool saveCorrectionNote(String insightId, String rawNote) {
    final normalized = normalizeCorrectionNote(rawNote);
    if (normalized == null) return false;
    _correctionNotes[insightId] = normalized;
    _persist();
    return true;
  }

  static void record(
    String insightId,
    ArchiveInsightFeedbackChoice choice,
  ) {
    switch (choice) {
      case ArchiveInsightFeedbackChoice.feelsRight:
        _feelsRight[insightId] = feelsRightCount(insightId) + 1;
      case ArchiveInsightFeedbackChoice.notQuite:
        _notQuite[insightId] = notQuiteCount(insightId) + 1;
    }
    _persist();
  }

  static void hide(String insightId) {
    _hidden.add(insightId);
    _persist();
  }

  static void unhide(String insightId) {
    _hidden.remove(insightId);
    _persist();
  }

  static void clearFeedback(String insightId) {
    _feelsRight.remove(insightId);
    _notQuite.remove(insightId);
    _persist();
  }

  static void deleteCorrectionNote(String insightId) {
    _correctionNotes.remove(insightId);
    _persist();
  }

  static int totalFeelsRightCount() =>
      _feelsRight.values.fold<int>(0, (sum, count) => sum + count);

  static int totalNotQuiteCount() =>
      _notQuite.values.fold<int>(0, (sum, count) => sum + count);

  static int hiddenInsightCount() => _hidden.length;

  static int correctionNoteCount() => _correctionNotes.length;

  static bool hasAnyFeedback() =>
      totalFeelsRightCount() > 0 ||
      totalNotQuiteCount() > 0 ||
      hiddenInsightCount() > 0 ||
      correctionNoteCount() > 0;

  static List<String> allKnownInsightIds() {
    final ids = <String>{
      ..._hidden,
      ..._feelsRight.keys,
      ..._notQuite.keys,
      ..._correctionNotes.keys,
    };
    final sorted = ids.toList()..sort();
    return sorted;
  }

  static List<String> notQuiteInsightIds() {
    final ids = _notQuite.entries
        .where((entry) => entry.value > 0)
        .map((entry) => entry.key)
        .toList()
      ..sort();
    return ids;
  }

  static List<String> hiddenInsightIds() {
    final ids = _hidden.toList()..sort();
    return ids;
  }

  static List<String> correctionNoteInsightIds() {
    final ids = _correctionNotes.keys.toList()..sort();
    return ids;
  }

  static Future<void> ensureLoaded() async {
    if (!AppServices.isInitialized) return;
    final raw = await AppServices.instance.prefs.readMap(_prefsKey);
    if (raw == null) return;
    _hidden
      ..clear()
      ..addAll(
        (raw['hidden'] as List<dynamic>? ?? []).whereType<String>(),
      );
    _feelsRight.clear();
    final feelsRightRaw = raw['feelsRight'];
    if (feelsRightRaw is Map) {
      for (final entry in feelsRightRaw.entries) {
        final key = entry.key?.toString();
        final value = entry.value;
        if (key != null && value is num) {
          _feelsRight[key] = value.toInt();
        }
      }
    }
    _notQuite.clear();
    final notQuiteRaw = raw['notQuite'];
    if (notQuiteRaw is Map) {
      for (final entry in notQuiteRaw.entries) {
        final key = entry.key?.toString();
        final value = entry.value;
        if (key != null && value is num) {
          _notQuite[key] = value.toInt();
        }
      }
    }
    _correctionNotes.clear();
    final notesRaw = raw['correctionNotes'];
    if (notesRaw is Map) {
      for (final entry in notesRaw.entries) {
        final key = entry.key?.toString();
        final value = entry.value?.toString().trim();
        if (key != null && value != null && value.isNotEmpty) {
          final normalized = normalizeCorrectionNote(value);
          if (normalized != null) {
            _correctionNotes[key] = normalized;
          }
        }
      }
    }
  }

  static void _persist() {
    if (!AppServices.isInitialized) return;
    // ignore: discarded_futures
    _persistAsync();
  }

  static Future<void> _persistAsync() async {
    if (!AppServices.isInitialized) return;
    await AppServices.instance.prefs.writeMap(_prefsKey, {
      'hidden': _hidden.toList()..sort(),
      'feelsRight': _feelsRight,
      'notQuite': _notQuite,
      'correctionNotes': _correctionNotes,
    });
  }

  static Future<void> clearAll() async {
    _hidden.clear();
    _feelsRight.clear();
    _notQuite.clear();
    _correctionNotes.clear();
    await _persistAsync();
  }

  @visibleForTesting
  static void resetForTest() {
    _hidden.clear();
    _feelsRight.clear();
    _notQuite.clear();
    _correctionNotes.clear();
  }
}
