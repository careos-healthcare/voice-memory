import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../config/screenshot_mode.dart';
import '../features/app_review/archive_app_review_session.dart';
import '../features/activation/activation_tracker.dart';
import '../features/activation/first_loop_activation_coordinator.dart';
import '../features/pro_bridge_visibility/delayed_paywall_proof_store.dart';
import 'archive_entitlement_reader.dart';
import 'archive_pro_feature_map.dart';
import 'paywall_route_args.dart';
import 'paywall_trigger_engine.dart';
import 'paywall_trigger_model.dart';

/// Loads access state and opens the paywall when a Pro feature is gated.
abstract class PaywallAccess {
  PaywallAccess._();

  static Future<bool> isFirstLoopClosed() async {
    final state = await FirstLoopActivationCoordinator.load();
    return state.isComplete;
  }

  static Future<PaywallTriggerContext?> check({
    required ArchiveFeature feature,
    ArchiveEntitlementReader? entitlementReader,
    bool? firstLoopClosed,
    int momentCount = 0,
    int checkInCount = 0,
    int weekCount = 0,
    String sourceRoute = '',
  }) async {
    final reader =
        entitlementReader ?? ArchiveEntitlementReader.forAccessCheck();
    final isPro = await reader.isPro;
    final loopClosed = firstLoopClosed ?? await isFirstLoopClosed();
    return buildPaywallTrigger(
      feature: feature,
      isPro: isPro,
      firstLoopClosed: loopClosed,
      momentCount: momentCount,
      checkInCount: checkInCount,
      weekCount: weekCount,
      sourceRoute: sourceRoute,
    );
  }

  /// Returns true when access is allowed; otherwise opens paywall and returns false.
  static Future<bool> ensureAccess(
    BuildContext context, {
    required ArchiveFeature feature,
    ArchiveEntitlementReader? entitlementReader,
    bool? firstLoopClosed,
    int momentCount = 0,
    int checkInCount = 0,
    int weekCount = 0,
    String sourceRoute = '',
  }) async {
    final trigger = await check(
      feature: feature,
      entitlementReader: entitlementReader,
      firstLoopClosed: firstLoopClosed,
      momentCount: momentCount,
      checkInCount: checkInCount,
      weekCount: weekCount,
      sourceRoute: sourceRoute,
    );
    if (trigger == null) return true;
    if (!context.mounted) return false;
    if (!await canOpenPaywall()) return false;
    if (!context.mounted) return false;
    await openPaywall(context, trigger);
    return false;
  }

  /// Paywall only after first repeat and evidence trail — same gate as Pro bridge.
  static Future<bool> canOpenPaywall() async {
    if (ScreenshotMode.enabled) return true;
    if (ArchiveAppReviewSession.isActive) return true;
    await DelayedPaywallProofStore.ensureLoaded();
    return DelayedPaywallProofStore.passesGate;
  }

  static Future<void> openPaywall(
    BuildContext context,
    PaywallTriggerContext trigger,
  ) async {
    if (!await canOpenPaywall()) return;
    if (!context.mounted) return;
    ActivationTracker.trackPaywallTriggerShown();
    context.push('/subscription', extra: PaywallRouteArgs.fromContext(trigger));
  }
}
